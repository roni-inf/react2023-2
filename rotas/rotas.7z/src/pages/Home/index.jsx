import React from 'react'
import './style.css';

export default function Home() {
  return (
    <div>
        <h1>Página principal da Empresa</h1>
    </div>
  )
}

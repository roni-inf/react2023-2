import React from 'react'

export default function Noticias() {
  return (
    <div>
        <h2>Notícias...... </h2>    
    </div>
  )
}

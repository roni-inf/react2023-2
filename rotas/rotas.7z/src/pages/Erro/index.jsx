import React from 'react'

export default function Erro() {
  return (
    <div>
        <h1>Erro 404 - Página não encontrada !</h1>
    </div>
  )
}

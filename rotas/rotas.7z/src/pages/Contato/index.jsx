import React from 'react'
import './style.css';
export default function Contato() {
  return (
    <div>
        <h2>telefone: (24)9898-0989 </h2>    
    </div>
  )
}

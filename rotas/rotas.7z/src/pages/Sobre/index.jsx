import React from 'react'

export default function Sobre() {
  return (
    <div>
        <h2>Sobre..... </h2>    
    </div>
  )
}

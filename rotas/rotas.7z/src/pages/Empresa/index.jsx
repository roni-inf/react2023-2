import React from 'react'

export default function Empresa() {
  return (
    <div>
        <h2>A Empresa foi criada em..... </h2>    
    </div>
  )
}

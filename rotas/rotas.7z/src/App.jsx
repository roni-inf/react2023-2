import { BrowserRouter } from "react-router-dom";
import Header from "./components/Header";
import AppRouter from "./routes";

export default function App() {
  return (
    <>
      <BrowserRouter>
        <Header />
        <AppRouter />
      </BrowserRouter>
    </>
  );
}
